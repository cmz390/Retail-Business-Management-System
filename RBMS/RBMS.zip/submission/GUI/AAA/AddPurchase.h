//
//  AddPurchase.h
//  AAA
//
//  Created by MingzhaoChen on 11/26/17.
//  Copyright © 2017 MingzhaoChen. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AddPurchase : NSViewController
@property (weak) IBOutlet NSButton *run;
@property (weak) IBOutlet NSTextField *get;
@property (weak) IBOutlet NSTextField *out;
@property (weak) IBOutlet NSTextField *get2;
@property (weak) IBOutlet NSTextField *get3;
@property (weak) IBOutlet NSTextField *get4;

@end


