//
//  table.h
//  AAA
//
//  Created by MingzhaoChen on 11/26/17.
//  Copyright © 2017 MingzhaoChen. All rights reserved.
//


#import <Cocoa/Cocoa.h>

@interface table : NSViewController
@property (weak) IBOutlet NSButton *log;
@property (weak) IBOutlet NSButton *products;
@property (weak) IBOutlet NSButton *supplier;
@property (weak) IBOutlet NSButton *suppplies;
@property (weak) IBOutlet NSButton *customers;
@property (weak) IBOutlet NSButton *employees;
@property (weak) IBOutlet NSButton *discounts;
@property (weak) IBOutlet NSButton *purchases;


@end
